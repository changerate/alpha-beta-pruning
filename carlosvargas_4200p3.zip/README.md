# Alpha-Beta Pruning and A 8x8 Tic-Tac-Toe Game

A tic tac toe game that can beat you. 

For CS 4200, Artificial Intelligence, at California State Polytechnic University - Pomona.

# Setup
1. Navigate to the `alpha-beta-pruning` directory (root). 
2. run `python main.py`